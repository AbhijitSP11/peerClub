export const API_LINK = "http://localhost:1337";
