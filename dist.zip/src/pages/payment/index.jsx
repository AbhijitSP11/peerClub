import React from "react";
import PaymentPage from "../../components/page/payment";

const Payment = () => {
  return (
    <div>
      <PaymentPage />
    </div>
  );
};

export default Payment;
