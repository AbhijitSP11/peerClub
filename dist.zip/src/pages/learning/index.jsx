import React from "react";
import styles from "./styles.modules.scss";

const Learning = () => {
  return <div>index</div>;
};

export default Learning;
