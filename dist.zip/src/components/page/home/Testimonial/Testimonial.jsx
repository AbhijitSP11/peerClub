import React from 'react';
import TestimonialCard from './TestimonialCard';
import courseImg1 from '../../../../../public/static/testimon.jpg';
import styles from './Testimonial.module.css';

const coursesData = [
    {
        id: '01',
        title: 'Harshal Khatri',
        imgUrl: courseImg1,
        description:
            'My experience with peerpowerclub was very good and I learn lot of   technical stuff from my instructor.',
    },

    {
        id: '02',
        title: 'Harshal Khatri',
        imgUrl: courseImg1,
        description:
            'My experience with peerpowerclub was very good and I learn lot of   technical stuff from my instructor.',
    },

    {
        id: '03',
        title: 'Harshal Khatri',
        imgUrl: courseImg1,
        description:
            'My experience with peerpowerclub was very good and I learn lot of   technical stuff from my instructor.',
    },
];

const Testimonial = () => {
    return (
        <div className={styles.container}>
            <div className={styles.header__top}>
                <h1>Testimonial</h1>
            </div>
            <div className={styles.testimonialContainer}>
                {coursesData.map((item) => (
                    <div>
                        <TestimonialCard key={item.id} item={item} />
                    </div>
                ))}
            </div>
        </div>
    );
};

export default Testimonial;
