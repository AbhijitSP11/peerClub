import React from "react";
import Card from "../../../ui/card";
import styles from "./styles.module.scss";
import { MdWorkOutline } from "react-icons/md";
import { BsBook } from "react-icons/bs";
import { AiOutlineHome } from "react-icons/ai";

const CardList = () => {
  return (
    <div className={styles.container}>
      <div className={styles.list}>
        <Card
          title={"Digital Marketing"}
          excerpt={
            "If you have are persuasive and have a creative side then this course is for you. Learn the ABC’s of digital marketing and become the best in the game."
          }
          icon={"../../../../../dist/assets/static/public.jpg"}
          id={1}
        />
        <Card
          title={"Communication and Public Speaking"}
          excerpt={
            "For the leader in you, learn how to communicate in a formal setting and enhance your public speaking skills with the help of this course."
          }
          icon={"../../../../../dist/assets/static/public.jpg"}
          id={2}
        />
        <Card
          title={"Python Programming"}
          excerpt={
            "For the tech enthusiast in you, learn python a general purpose programming language used for web development, AI, machine learning and developing video games."
          }
          icon={"../../../../../dist/assets/static/python.jpeg"}
          id={3}
        />
      </div>

      {/* <div className={styles.list2}>
                <Card
                    title={'Invest in canada'}
                    excerpt={
                        'Did you know that you can migrate to Canada on the basis of your past work experience or sometimes no/minimal experience required?'
                    }
                    icon={'./static/study.svg'}
                    id={4}
                />
                <Card
                    title={'Permanent residency'}
                    excerpt={
                        'Did you know that you can migrate to Canada on the basis of your past work experience or sometimes no/minimal?'
                    }
                    icon={'./static/study.svg'}
                    id={5}
                />
            </div> */}
    </div>
  );
};

export default CardList;
