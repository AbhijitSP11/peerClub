import { Link } from "react-router-dom";
import React, { useState } from "react";
import styles from "./styles.module.scss";
import Fade from "react-reveal/Fade";

const services = [
  {
    id: 1,
    name: "Work in Enjoyable Environment",
    content:
      "Canada consistently ranks as one of the best countries in the World—and is currently the #1 best country for quality of life. ",
    image: "./static/study.png",
  },
  {
    id: 2,
    name: "Passive Income",
    content: `Canada has a very low unemployment rate compared to other developed countries. 
        It is rapidly advancing in modern technology making 
        it an ideal place for careers in software development or information technology. `,
    image: "./static/work.png",
  },
  {
    id: 3,
    name: "Become a part of Community",
    content: `Global market access, Unparalleled talent, Low costs, Reduced Risk 
            These are just some of the reasons World-leading companies 
            are setting up shop in Canada.`,
    image: "./static/immigrate.png",
  },
];

const ServiceList = () => {
  const [item, setItem] = useState(0);
  return (
    <div className={styles.container}>
      <Fade left>
        <div className={styles.left}>
          <img
            src={services[item].image}
            alt="study in canada with canada gateway"
          />
        </div>
      </Fade>
      <Fade right>
        <div className={styles.right}>
          <ul>
            {services.map((service, i) => (
              <li
                key={i}
                className={i === item ? styles.active : ""}
                onClick={() => setItem(i)}
              >
                <h4>{service.name}</h4>
                <p>{service.content}</p>
                <span
                  style={{
                    borderColor: i === item ? "white" : "black",
                  }}
                ></span>
              </li>
            ))}
          </ul>
          <div>
            <Link to={`/services`}>and much more.</Link>
          </div>
        </div>
      </Fade>
    </div>
  );
};

export default ServiceList;
